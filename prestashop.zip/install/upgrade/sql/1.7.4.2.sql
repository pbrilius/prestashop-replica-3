SET SESSION sql_mode = '';
SET NAMES 'utf8';

UPDATE `PREFIX_employee` SET `bo_css` = "theme.css";
